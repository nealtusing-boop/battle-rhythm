import type { MetadataRoute } from 'next';

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: 'Battle Rhythm',
    short_name: 'Battle Rhythm',
    description: 'Mobile-first platoon operations hub.',
    start_url: '/home',
    display: 'standalone',
    background_color: '#0a0a0c',
    theme_color: '#0a0a0c',
    orientation: 'portrait',
    icons: [
      {
        src: '/icons/icon-192.png',
        sizes: '192x192',
        type: 'image/png',
      },
      {
        src: '/icons/icon-512.png',
        sizes: '512x512',
        type: 'image/png',
      },
      {
        src: '/icons/icon-512.png',
        sizes: '512x512',
        type: 'image/png',
        purpose: 'maskable',
      },
    ],
  };
}